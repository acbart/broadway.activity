#ifndef PYMEDIA_VERSION_FULL
#define PYMEDIA_VERSION_FULL "1.3.7.0"
#endif

#ifndef PYMEDIA_VERSION
#define PYMEDIA_VERSION ""
#endif
