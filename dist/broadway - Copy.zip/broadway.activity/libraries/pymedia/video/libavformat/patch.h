#ifndef _PATCH_H_
#define _PATCH_H_

typedef struct OutputBuf {
	uint8_t* buffer;
	int buf_size;
} OutputBuf;


#endif

