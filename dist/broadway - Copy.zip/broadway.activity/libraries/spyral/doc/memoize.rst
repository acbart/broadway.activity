Memoization classes
===================

.. automodule:: spyral.memoize
   :members: