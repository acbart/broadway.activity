Cameras
#######

Cameras are an integral part of spyral's display operations. They handle the 
advanced features including layering and scaling. To get the default camera,
call *spyral.director.get_camera()*.

.. automodule:: spyral.camera
   :members: