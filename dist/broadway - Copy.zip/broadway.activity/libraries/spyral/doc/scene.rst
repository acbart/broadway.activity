The Director and Scenes
#######################
The Director manages the running scenes. There is a director as spyral.director
which should be used for games.

.. automodule:: spyral.scene
   :members: