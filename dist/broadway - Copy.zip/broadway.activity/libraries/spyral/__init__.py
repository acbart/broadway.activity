import spyral.memoize
import spyral.point
import spyral.camera
import spyral.util
import spyral.sprite
import spyral.gui
import spyral.scene
import spyral._lib
import pygame

director = scene.Director()

def init():
    pygame.init()
    pygame.font.init()